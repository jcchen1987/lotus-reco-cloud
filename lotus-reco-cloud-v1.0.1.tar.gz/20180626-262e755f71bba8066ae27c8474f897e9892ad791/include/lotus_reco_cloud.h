#ifndef __LOTUS_RECO_CLOUD_H__
#define __LOTUS_RECO_CLOUD_H__

#include <map>
#include <string>
using std::map;
using std::string;

/**
* @brief definition for dll export on Windows
*/
#ifdef WIN32
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

/**
* @brief image format enumeration
*/
enum EImgFormat
{
    EImgFormat_I420 = 0,  ///< YUV420 memory layout: Y(w x h).. U(w/2 x h/2).. V(w/2 x h/2)..
    EImgformat_BGR        ///< BGR  memory layout: BGRBGR...
};

/**
* @brief a common image struct
*/
template<typename T>
struct TImage
{
    T *pData;           ///< image data
    int nWidth;         ///< image width
    int nHeight;        ///< image height
    EImgFormat eFormat; ///< image format
};
typedef TImage<unsigned char> TImageU;

/**
* @brief feature vector
*        key:   feature vector index
*        value: feature vector weight
*/
typedef map<int, float> TFeatureVector;

/**
* @brief caffe model parameters
*/
struct TCaffeModelParam
{
    string strProto;                      ///< the net config file, xxx.proto
    string strModel;                      ///< the net weights, xxx.caffemodel
    string strBlobName = string("pool5"); ///< the feature blob name, do not change it!!!
};

/**
* @brief general feature extractor class
*/
class EXPORT CFeatExtractor
{
public:
    /**
    * @brief create extractor handle
    * @param tCaffeModelParam   the caffe model net config and weights files @see TCaffeModelParam
    * @return the feature extractor handle
    *         -<em>NULL</em> failed
    */
    static CFeatExtractor *CreateExtractor(const TCaffeModelParam &tCaffeModelParam);

    /**
    * @brief destroy extractor handle
    * @param ptExtractor   the extractor handle which is created by CreateExtractor
    */
    static void DestoryExtractor(CFeatExtractor *ptExtractor);

    /**
    * @brief extract feature from an image
    * @param tImg       the input image for feature extraction @see TImageU
    * @param tFeatVec   the output feature vector @see TFeatureVector
    * @return the error code
    *         -<em> 0 </em>        success
    *         -<em> non-zero </em> error code
    */
    virtual int Extract(const TImageU &tImg, TFeatureVector &tFeatVec) = 0;

public:
    virtual ~CFeatExtractor() {};
};

/**
* @brief compute similarity between two feature vector, the higher the better
*        sim = cos(f1, f2) = f1 * f2 / (|f1||f2|)
* @param f1 the first feature vector
* @param f2 the second feature vector
* @return the similarity between f1 and f2
*/
float EXPORT FeatureSimilarity(TFeatureVector &f1, TFeatureVector &f2);

/**
* @brief compute the similar score of two images, the higher the better
* @param tImg1 the first image
* @param tImg2 the second image
* @return the similarity between tImg1 and tImg2
*/
float EXPORT ImgSimilarity(TImageU &tImg1, TImageU &tImg2);
#endif
