#ifndef __IMG_LOADER_H__
#define __IMG_LOADER_H__

#include "lotus_reco_cloud.h"

/**
* @brief load image from file
*        the buffer is malloced in this function, it should be released after used        
* @param strImageName  the image file name
* @return Image struct @see TImageU
*/
TImageU EXPORT LoadImage(const string & strImageName);

/**
* @brief release image buffer which is returned by LoadImage
*        ps: do not release the TImage struct which is created by yourself
* @param tImg  the image struct to be released
*/
void EXPORT ReleaseImage(TImageU &tImg);

#endif
