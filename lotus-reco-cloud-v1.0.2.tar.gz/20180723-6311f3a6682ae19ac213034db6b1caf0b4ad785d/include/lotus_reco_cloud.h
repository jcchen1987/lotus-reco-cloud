#ifndef __LOTUS_RECO_CLOUD_H__
#define __LOTUS_RECO_CLOUD_H__

#include <map>
#include <string>
using std::map;
using std::string;

/**
* @brief definition for dll export on Windows
*/
#ifdef WIN32
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

/**
* @brief image format enumeration
*/
enum ImgFormat
{
    IMG_FORMAT_I420 = 0,  ///< YUV420 memory layout: Y(w x h).. U(w/2 x h/2).. V(w/2 x h/2)..
    IMG_FORMAT_BGR        ///< BGR  memory layout: BGRBGR...
};

/**
* @brief a common image struct
*/
template<typename T>
struct ImageT
{
    T *data;          ///< image data
    int width;        ///< image width
    int height;       ///< image height
    ImgFormat format; ///< image format
};
typedef ImageT<unsigned char> ImageU;

/**
* @brief feature vector
*        key:   feature vector index
*        value: feature vector weight
*/
typedef map<int, float> FeatureVector;

/**
* @brief caffe model parameters
*/
struct CaffeModelParam
{
    string proto;                  ///< the net config file, xxx.proto
    string model;                  ///< the net weights, xxx.caffemodel
    string blob = string("pool5"); ///< the feature blob name, do not change it!!!
};

/**
* @brief general feature extractor class
*/
class EXPORT FeatExtractor
{
public:
    /**
    * @brief create extractor handle
    * @param param   the caffe model net config and weights files @see CaffeModelParam
    * @return the feature extractor handle
    *         -<em>NULL</em> failed
    */
    static FeatExtractor *Create(const CaffeModelParam &param);

    /**
    * @brief destroy extractor handle
    * @param extractor   the extractor handle which is created by Create
    */
    static void Destory(FeatExtractor *extractor);

    /**
    * @brief extract feature from an image
    * @param img        the input image for feature extraction @see ImageU
    * @param feat_vec   the output feature vector @see TFeatureVector
    * @return the error code
    *         -<em> 0 </em>        success
    *         -<em> non-zero </em> error code
    */
    virtual int Extract(const ImageU &img, FeatureVector &feat_vec) = 0;

public:
    virtual ~FeatExtractor() {};
};

/**
* @brief compute similarity between two feature vector, the higher the better
*        sim = cos(f1, f2) = f1 * f2 / (|f1||f2|)
* @param f1 the first feature vector
* @param f2 the second feature vector
* @return the similarity between f1 and f2
*/
float EXPORT FeatureSimilarity(const FeatureVector &fv1, const FeatureVector &fv2);

/**
* @brief compute the similar score of two images, the higher the better
* @param img1 the first image
* @param img2 the second image
* @return the similarity between img1 and img2
*/
float EXPORT ImgSimilarity(const ImageU &img1, const ImageU &img2);
#endif
