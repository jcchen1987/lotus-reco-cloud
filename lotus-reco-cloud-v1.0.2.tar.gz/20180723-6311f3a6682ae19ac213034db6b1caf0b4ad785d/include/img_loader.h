#ifndef __IMG_LOADER_H__
#define __IMG_LOADER_H__

#include "lotus_reco_cloud.h"

/**
* @brief Load image from file
*        the buffer is malloced in this function, it should be released after used        
* @param img_name  the image file name
* @return Image struct @see ImageU
*/
ImageU EXPORT LoadImage(const string & img_name);

/**
* @brief release image buffer which is returned by LoadImage
*        ps: do not release the ImageT struct which is created by yourself
* @param img  the image struct to be released
*/
void EXPORT ReleaseImage(ImageU &img);

#endif
