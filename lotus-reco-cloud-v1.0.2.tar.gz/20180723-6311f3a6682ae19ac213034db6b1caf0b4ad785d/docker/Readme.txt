1. install nvidia driver
2. install docker-ce
3. install nvidia-docker
4. build docker image with the Dockerfile: docker build -t <image name:tag> .
5. run image with nvidia-docker